Please follow the link below for the required description

https://www.researchgate.net/publication/303792317_EXPERIMENTAL_DATASET_FOR_GEAR_FAULT_DIAGNOSIS